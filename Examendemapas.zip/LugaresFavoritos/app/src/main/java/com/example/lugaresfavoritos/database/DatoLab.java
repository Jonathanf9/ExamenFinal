package com.example.lugaresfavoritos.database;

import android.annotation.SuppressLint;
import android.content.Context;

import androidx.room.Room;

import java.util.List;

public class DatoLab {
    @SuppressLint("StaticFieldLeak")

    private static DatoLab sDatoLab;
    private static DatoDao mDatoDao;

    public DatoLab (Context context){
        Context appContext=context.getApplicationContext();
        DatoDatabase database = Room.databaseBuilder(appContext,DatoDatabase.class,"datos")
                .allowMainThreadQueries().build();
        mDatoDao=database.geDatoDao();
    }
    public static DatoLab get(Context context){
        if(sDatoLab==null){
            sDatoLab=new DatoLab(context);
        }
        return sDatoLab;
    }

    //Método para obtener todas las personas de la lista
    public List<Dato> getPersonas() {
        return mDatoDao.getDato();
    }
    //Método para obtener una sola persona de la lista por su id
    public Dato getPersona(String id) {
        return mDatoDao.getDato(id);
    }
    //Método para guardar una persona
    public void addPersona(Dato dato) {
        mDatoDao.addDato(dato);
    }
    //Método para actualizar una persona
    public void updatePersona(Dato dato) {
        mDatoDao.updateDato(dato);
    }
    //Método para eliminar una persona
    public void deletePersona(Dato dato) {
        mDatoDao.deleteDato(dato);
    }
    //Método para borrar todas las persona
    public void deleteAllPersona() {
        mDatoDao.deleteAllDato();
    }


}
