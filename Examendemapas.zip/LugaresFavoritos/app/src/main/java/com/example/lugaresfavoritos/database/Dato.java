package com.example.lugaresfavoritos.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity ( tableName = "lugares")
    public class Dato {
    public Dato(String nombre, String categoria, String descripcion, String latitud, String longitud) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    @PrimaryKey(autoGenerate = true)
    @NonNull
    private int id;

    @ColumnInfo(name = "nombre")
    private String nombre;

    @ColumnInfo(name = "categoria")
    private String categoria;

    @ColumnInfo(name = "descripcion")
    private String descripcion;

    @ColumnInfo(name = "latitud")
    private String latitud;

    @ColumnInfo(name = "longitud")
    private String longitud;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }
}


