package com.example.lugaresfavoritos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lugaresfavoritos.database.Dato;
import com.example.lugaresfavoritos.database.DatoLab;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;

import java.util.ArrayList;

public class Mostrar_Activity extends AppCompatActivity implements View.OnClickListener{
    /*DEFINIMOS LAS VARIABLES*/
    private ArrayList<Dato> listaDatos = new ArrayList<>();
    private DatoLab mPersonaLab;
    private Dato mPersona;
    public TextView nombre,latitud,longitud;
    private Button btnvolver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);

        /*DEFINICION DE BASE DE DATOS*/
        mPersonaLab = new DatoLab(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        /*INTENTS PARA SACAR EL ID Y MSOTRAR EN LA ACTIVITY*/
        Intent inten = getIntent();
        String id= inten.getStringExtra("id");
        Integer id2=Integer.parseInt(id);

        /*LLAMAMOS AL METODO DE TRAER DATOS*/
        getAllPersonas();
        mPersona=listaDatos.get(id2);

        /*DEFINIMOS LA UBICACION DE LOS XML*/
        nombre = (TextView) findViewById(R.id.view_nombre);


        latitud = (TextView) findViewById(R.id.view_latitud);
        longitud = (TextView) findViewById(R.id.view_longitud);


        /*DEFINIMOS LA UBICACION DE LOS BOTONEES*/
        btnvolver = (Button) findViewById(R.id.Vbutton_volver);
        btnvolver.setOnClickListener(this);


        /*ENVIAMOS LOS DATOS EXTRAIDOS DE LOS VIEWS*/
        nombre.setText(mPersona.getNombre());

        latitud.setText(mPersona.getLatitud());
        longitud.setText(mPersona.getLongitud());

    }

    /*ACCION DE LOS BOTONES*/
    @Override
    public void onClick(View view) {
        if(view==btnvolver){

            Intent intent = new Intent(Mostrar_Activity.this, MainActivity.class);
            startActivity(intent);
        }

    }
    public void getAllPersonas(){
        listaDatos.addAll(mPersonaLab.getPersonas());
    }
}