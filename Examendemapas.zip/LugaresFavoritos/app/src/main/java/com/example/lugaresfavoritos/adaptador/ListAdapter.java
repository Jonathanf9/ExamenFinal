package com.example.lugaresfavoritos.adaptador;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.lugaresfavoritos.R;
import com.example.lugaresfavoritos.database.Dato;

import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<Dato> {
    /*DEFINIMOS UN CONTEXTO Y UN ARRAY */
    private Context context;
    private ArrayList<Dato> list;

    /*CONTRUCTOR PARA EL ARRAY EL CONTEXTO Y LA LISTA*/
    public ListAdapter(Context context,ArrayList<Dato> list){
        super(context, R.layout.list_view);
        this.context=context;
        this.list=list;
    }

    @Override
    public int getCount(){
        return list.size();
    }

    /*TRAER VISTA DE LA LISTVIEW*/
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view;
        /*DEFNIMOS UN VIEWHOLDER*/
        final ViewHolder viewHolder;
        if (convertView == null || convertView.getTag() == null) {

            /*DEFINIMOS VARIABLES */
            viewHolder=new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.list_view,parent,false);
            viewHolder.vItemName=(TextView) view.findViewById(R.id.textList);
           
            view.setTag(viewHolder);
        }else{

            viewHolder = (ViewHolder) convertView.getTag();
            view = convertView;
        }

        viewHolder.vItemName.setText(list.get(position).getNombre());

        return view;
    }

static class ViewHolder{
        protected TextView vItemName;
        protected ImageView vItemImage;
    }

}

