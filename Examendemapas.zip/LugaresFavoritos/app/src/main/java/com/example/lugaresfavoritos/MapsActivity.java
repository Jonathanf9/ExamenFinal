package com.example.lugaresfavoritos;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.lugaresfavoritos.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, View.OnClickListener,
        GoogleMap.OnMapLongClickListener{

    private GoogleMap mMap;

    double longi, lat;
    Button btnUbica;
    private FusedLocationProviderClient fusedLocationClient;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        @NonNull ActivityMapsBinding binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        btnUbica = findViewById(R.id.btnlocal1);
        btnUbica.setOnClickListener(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        habilitarPermisos();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap=googleMap;
        mMap.setOnMapLongClickListener(this);

    }


    @Override
    public void onMapLongClick(LatLng latLng) {
        Toast.makeText(this, "mi ubicacion "+latLng.latitude+" "+latLng.longitude, Toast.LENGTH_LONG).show();
        LatLng posicion = new LatLng(lat, longi );
        mMap.addMarker(new MarkerOptions().position(posicion).title("Marcar mi ubicacion").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(posicion));
        CameraUpdate miUbicacion = CameraUpdateFactory.newLatLngZoom(posicion, 10);
        mMap.animateCamera(miUbicacion);

        sharedPreferences = getSharedPreferences("MiPreferencia", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();

        ed.putFloat("latitud",(float) latLng.latitude);
        ed.putFloat("longitud",(float) latLng.longitude);
        ed.commit();

    }

    public void habilitarPermisos() {
        ActivityResultLauncher<String[]> locationPermissionRequest =
                registerForActivityResult(new ActivityResultContracts
                                .RequestMultiplePermissions(), result -> {
                            Boolean fineLocationGranted = result.getOrDefault(
                                    Manifest.permission.ACCESS_FINE_LOCATION, false);
                            Boolean coarseLocationGranted = result.getOrDefault(
                                    Manifest.permission.ACCESS_COARSE_LOCATION, false);

                            if (fineLocationGranted != null && fineLocationGranted) {

                            } else if (coarseLocationGranted != null && coarseLocationGranted) {

                            } else {

                            }
                        }
                );

        locationPermissionRequest.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });
    }


    public void cargarUbicacionFav(){
        sharedPreferences = getSharedPreferences("MiPreferencia",Context.MODE_PRIVATE);

        Float latitudfav = sharedPreferences.getFloat("latitud", 0);
        Float longitudfav = sharedPreferences.getFloat("longitud",0);

        Toast.makeText(this, "Ubicacion Favorita "+latitudfav+" "+ longitudfav, Toast.LENGTH_LONG).show();

        if (latitudfav != 0){
            CameraUpdate cam = CameraUpdateFactory.newLatLng(new LatLng(latitudfav,longitudfav));
            mMap.moveCamera(cam);
        }else{
            Toast.makeText(this, "su localizacion se ha cambiado", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onClick(View v) {
        if (v == btnUbica){
            Intent intent = new Intent(MapsActivity.this, Save_Activity.class);
            startActivity(intent);
        }
    }
}