package com.example.lugaresfavoritos.database;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DatoDao {
    @Query("SELECT * FROM lugares")
    List<Dato> getDato();

    @Query("SELECT * FROM lugares WHERE id LIKE :uuid")
    Dato getDato(String uuid);

    @Insert
    void addDato(Dato p);

    @Delete
    void deleteDato(Dato p);

    @Update
    void updateDato(Dato p);

    @Query("DELETE FROM lugares")
    void deleteAllDato();
}
