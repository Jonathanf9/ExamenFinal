package com.example.lugaresfavoritos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Principal_Activity extends AppCompatActivity implements View.OnClickListener {

    private Button btnuevo,btnmostrar;
    private ImageView Agregar, Listar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        /*DEFINIR UBICACION DE BOTONOES EN EL XML*/

        btnuevo=(Button) findViewById(R.id.btnAgregar);
        btnmostrar=(Button) findViewById(R.id.btnListar);

        /*DEFINIMOS EL ONCLIK EN LOS BOTONES*/
        btnuevo.setOnClickListener(this);
        btnmostrar.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if (view ==btnuevo){
            Intent intent=new Intent(Principal_Activity.this, Save_Activity.class);
            startActivity(intent);
        }

        if (view==btnmostrar){
            Intent intent=new Intent(Principal_Activity.this, MainActivity.class);
            startActivity(intent);
        }
    }
}