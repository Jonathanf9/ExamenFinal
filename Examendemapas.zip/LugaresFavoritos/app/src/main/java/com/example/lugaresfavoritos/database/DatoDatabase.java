package com.example.lugaresfavoritos.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Dato.class},version = 1)

public abstract class DatoDatabase extends RoomDatabase {

    public abstract DatoDao geDatoDao();
}
