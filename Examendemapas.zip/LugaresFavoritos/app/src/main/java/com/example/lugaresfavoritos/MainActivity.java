package com.example.lugaresfavoritos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.example.lugaresfavoritos.adaptador.ListAdapter;
import com.example.lugaresfavoritos.database.Dato;
import com.example.lugaresfavoritos.database.DatoLab;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private ListAdapter listItemAdapter,list;
    private ArrayList<Dato> listaDatos = new ArrayList<>();
    private ListView listView;
    private DatoLab mDatoLab;
    private Dato mDato;

    private Button btnagregar,btneliminar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatoLab = new DatoLab(this);

        listView = (ListView) findViewById(R.id.list);



        btnagregar = (Button) findViewById(R.id.Vbutton_volver);
        btneliminar= (Button) findViewById(R.id.btn_eliminar);

        btnagregar.setOnClickListener(this);
        btneliminar.setOnClickListener(this);


        getAllPersonas();
        listItemAdapter = new ListAdapter(this, listaDatos);
        listView.setAdapter(listItemAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent  =  new Intent(MainActivity.this,Mostrar_Activity.class);
                intent.putExtra("id",""+i);
                startActivity(intent);
            }
        });
    }
    // CONSULTA A LA BASE DE DATOS
    public void getAllPersonas(){
        listaDatos.addAll(mDatoLab.getPersonas());
    }

    @Override
    public void onClick(View view) {
        if (view==btnagregar){
            Intent intent = new Intent(MainActivity.this, Save_Activity.class);
            startActivity(intent);
        }else if(view==btneliminar){
            mDatoLab.deleteAllPersona();
            listaDatos.clear();
            listItemAdapter.notifyDataSetChanged();
        }

    }
}