package com.example.lugaresfavoritos;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lugaresfavoritos.adaptador.ListAdapter;
import com.example.lugaresfavoritos.database.Dato;
import com.example.lugaresfavoritos.database.DatoLab;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;

public class Save_Activity extends AppCompatActivity implements View.OnClickListener{

    /* Definimos las variables y las clases*/
    public static final int REQUEST_CODE = 1;
    private ArrayList<Dato> listadato = new ArrayList<>();
    private DatoLab mDatoLab;
    private Dato mDato;
    private TextView nombre, categoria, descripcion,longitud,latitud;
    private Button btnguardar, btnlista, btncoordenadas;
    private LocationManager ubicacion;
    private FusedLocationProviderClient fusedLocationProviderClient;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);
        mDatoLab = new DatoLab(this);

        /*DEFINIR E IDENTIFICAR LOS CAMPOS DEL XML*/

        nombre = (TextView) findViewById(R.id.txtnombre);

        longitud = (TextView) findViewById(R.id.txt_longitud);
        latitud = (TextView) findViewById(R.id.txt_latitud);
        /*DEFINIMOS LOS BOTONES*/
        btnguardar = (Button) findViewById(R.id.Vbutton_volver);
        btnlista = (Button) findViewById(R.id.btn_lista);
        btncoordenadas = (Button) findViewById(R.id.btn_lista);

        /*IMPLEMENTAMOS ONCLIK A LOS BOTONES*/
        btnguardar.setOnClickListener(this);
        btnlista.setOnClickListener(this);
        btncoordenadas.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        /*DEFINIMOS ACCION DE LOS BOTONES*/
        if (view == btncoordenadas){
            Intent intent = new Intent(Save_Activity.this, MapsActivity.class);
            startActivity(intent);
        }
        if (view == btnlista) {
            Intent intent = new Intent(Save_Activity.this, MainActivity.class);
            startActivity(intent);
        }
        if (view == btnguardar) {
            /*GUARDAMOS EN LA BASE DE DATOS*/
            mDato = new Dato(
                    nombre.getText().toString(),
                    categoria.getText().toString(),
                    descripcion.getText().toString(),
                    latitud.getText().toString(),
                    longitud.getText().toString()
                    );
            mDatoLab.addPersona(mDato);

            /*LIMPIAMOS LOS CAMPOS*/
            nombre.setText(" ");
            categoria.setText(" ");
            descripcion.setText(" ");
            latitud.setText(" ");
            longitud.setText(" ");
        }
    }

    public void ObtenerCoordendasActual() {

        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Save_Activity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        } else {

            getCoordenada();
        }
    }
    @Override
    /*DEFINIMOS EL FUSED PARA HABILITAR SERVIICOS DE UBICACION*/
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCoordenada();
            } else {
                Toast.makeText(this, "Permiso Denegado ..", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void getCoordenada() {

        try {
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.setInterval(10000);
            locationRequest.setFastestInterval(3000);
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            LocationServices.getFusedLocationProviderClient(this).requestLocationUpdates(locationRequest, new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                    LocationServices.getFusedLocationProviderClient(Save_Activity.this).removeLocationUpdates(this);
                    if (locationResult != null && locationResult.getLocations().size() > 0) {
                        int latestLocationIndex = locationResult.getLocations().size() - 1;
                        double latitud = locationResult.getLocations().get(latestLocationIndex).getLatitude();
                        double longitude = locationResult.getLocations().get(latestLocationIndex).getLongitude();
                        longitud.setText(String.valueOf(longitude));

                    }
                }

            }, Looper.myLooper());

        }catch (Exception ex){
            System.out.println("Error es :" + ex);
        }
    }

}






